import ppa_utils

def confirm_works():
    print(dir(ppa_utils))

if __name__ == '__main__':
    confirm_works()
# About PPA utils

Utils are intended to be scripts that are used in all PPA reports for all programs.
The goal is that this one utils folder can be copied/pasted as a folder to all reports,
saving time and enabling better code organization.